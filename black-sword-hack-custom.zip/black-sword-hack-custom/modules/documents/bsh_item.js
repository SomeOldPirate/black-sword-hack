export class BSHItem extends Item {
    /** @override */
    prepareData() {
        super.prepareData();
    }
}
