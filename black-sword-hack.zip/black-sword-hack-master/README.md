# The Black Sword Hack - Unofficial

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/H2H645D60)

This repository contains an unofficial implemementation of The Black Sword Hack
for the FoundryVTT.

## Foreword

This work is totally free to use and comes with a very liberal license. That
being said it did take time, effort and skill on my part to work out how to do
it and to put it together. If you get some use out of this work, and can afford
to, I'd would ask you to show your appreciation for my efforts using the Ko-fi
link above. If nothing else it will make it more likely that I'll continue to
work on the system.

Feel free to submit bug reports through the Github issues tab but, given that
this is a free product, there will be no commitment to any kind of timelines. I
have to work for a living so if it's going to get addressed it will get addressed
when I have the free time to do so. You can also submit feature and enhancement
requests but I reserve the right to convert those that I think are worth doing into
[goals on Ko-fi](https://ko-fi.com/peterwood) to get some idea of how popular
the rquest is and to get some funding for doing it.

Thanks in advance.

## Documentation

Documentation for this system is my current goal in [Ko-fi](https://ko-fi.com/peterwood)
so if you want to see the documentation please go there and show your support.
