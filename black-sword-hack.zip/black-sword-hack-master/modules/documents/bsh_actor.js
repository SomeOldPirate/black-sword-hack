export class BSHActor extends Actor {
    /** @override */
    prepareData() {
        super.prepareData();
    }
}
